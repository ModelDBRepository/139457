%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = ou_f2(varargin)
% OU_F2 M-file for ou_f2.fig
%      OU_F2, by itself, creates a new OU_F2 or raises the existing
%      singleton*.
%
%      H = OU_F2 returns the handle to a new OU_F2 or the handle to
%      the existing singleton*.
%
%      OU_F2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OU_F2.M with the given input arguments.
%
%      OU_F2('Property','Value',...) creates a new OU_F2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ou_f2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ou_f2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ou_f2

% Last Modified by GUIDE v2.5 21-Jan-2009 16:22:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ou_f2_OpeningFcn, ...
                   'gui_OutputFcn',  @ou_f2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ou_f2 is made visible.
function ou_f2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ou_f2 (see VARARGIN)

% Choose default command line output for ou_f2
handles.output = hObject;

%
%first simulation
%

%mean excitatory conductance
ge0 = 0.012; %mu S 

%relaxation time constant and steady-state SD
tau_e = 2.7; %ms
sig_e = 0.003; %mu S

%time step and time vector
dt = 0.5; %ms
t_v = 0:dt:1000;
n_t_v = length(t_v);

%numerical simulation factors
ef_1 = exp(-dt/tau_e);
ef_2 = sqrt(1-exp(-2*dt/tau_e));

%initial value of the random conductance variable
x0 = 0;

%random white noise increment
w_ve = normrnd(0,1,1,n_t_v);
u_ve = sig_e*ef_2*w_ve;

%save space for random vector
x_ve = zeros(1,n_t_v);

%initial condition
x_ve(1) = x0;

for i =2:n_t_v
    %stochastic update
    x_ve(i) = x_ve(i-1)*ef_1 + u_ve(i);
end;

%add steady-state value
x_ve = x_ve + ge0;

line('Parent',handles.axes1,'XData',t_v,'YData',x_ve);
set(handles.axes1,'YLim',[0 0.04]);
xlabel(handles.axes1,'time (ms)');
ylabel(handles.axes1,'conductance (\mu S)');

%histogram of values
[ne, xoute] = hist(x_ve,20);

bar(handles.axes2,xoute,ne,'r');

ye = normpdf(xoute,ge0,sig_e);
ye = (sum(ne)/sum(ye)) * ye;

line('Parent',handles.axes2,'XData',xoute,'YData',ye);

set(handles.axes2,'TickDir','out','Xlim',[0 0.04]);
xlabel(handles.axes2,'conductance (\mu S)');

%power spectrum
f = 0:0.1:200;
pfe = 2*sig_e^2*tau_e*1e-3./(1 + (2*pi*f*tau_e*1e-3).^2);
line('Parent',handles.axes3,'XData',f,'YData',pfe);
xlabel(handles.axes3,'frequency (Hz)');
ylabel(handles.axes3,'Power density (\mu S^2 / Hz)');

%
%second simulation
%

%mean inhibitory conductance
gi0 = 0.057; %mu S 

%relaxation time constant and steady-state SD
tau_i = 10.5; %ms
sig_i = 0.0066; %mu S

%time step and time vector
dt = 0.5; %ms
t_v = 0:dt:1000;
n_t_v = length(t_v);

%numerical simulation factors
if_1 = exp(-dt/tau_i);
if_2 = sqrt(1-exp(-2*dt/tau_i));

%initial value of the random conductance variable
x0 = 0;

%random white noise increment
w_vi = normrnd(0,1,1,n_t_v);
u_vi = sig_i*if_2*w_vi;

%save space for random vector
x_vi = zeros(1,n_t_v);

%initial condition
x_vi(1) = x0;

for i =2:n_t_v
    %stochastic update
    x_vi(i) = x_vi(i-1)*if_1 + u_vi(i);
end;

%add steady-state value
x_vi = x_vi + gi0;

line('Parent',handles.axes4,'XData',t_v,'YData',x_vi);
set(handles.axes4,'YLim',[0.04 0.08]);
xlabel(handles.axes4,'time (ms)');
ylabel(handles.axes4,'conductance (\mu S)');

%histogram of values
[ni, xouti] = hist(x_vi,20);
bar(handles.axes5,xouti,ni,'r');

yi = normpdf(xouti,gi0,sig_i);
yi = (sum(ni)/sum(yi)) * yi;

line('Parent',handles.axes5,'XData',xouti,'YData',yi);

set(handles.axes5,'TickDir','out','Xlim',[0.02 0.1]);
xlabel(handles.axes5,'conductance (\mu S)');

%power spectrum
f = 0:0.1:200; %frequency in Hz
pfi = 2*sig_i^2*tau_i*1e-3./(1 + (2*pi*f*tau_i*1e-3).^2);
line('Parent',handles.axes6,'XData',f,'YData',pfi);
xlabel(handles.axes6,'frequency (Hz)');
ylabel(handles.axes6,'Power density (\mu S^2 / Hz)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ou_f2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ou_f2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','ou_f2.eps');


%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires lif_fr.m
%

function varargout = fi_curves(varargin)
% FI_CURVES M-file for fi_curves.fig
%      FI_CURVES, by itself, creates a new FI_CURVES or raises the existing
%      singleton*.
%
%      H = FI_CURVES returns the handle to a new FI_CURVES or the handle to
%      the existing singleton*.
%
%      FI_CURVES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FI_CURVES.M with the given input arguments.
%
%      FI_CURVES('Property','Value',...) creates a new FI_CURVES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fi_curves_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fi_curves_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fi_curves

% Last Modified by GUIDE v2.5 11-May-2010 21:15:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fi_curves_OpeningFcn, ...
                   'gui_OutputFcn',  @fi_curves_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fi_curves is made visible.
function fi_curves_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fi_curves (see VARARGIN)

% Choose default command line output for fi_curves
handles.output = hObject;

%plot the theoretical fI curve of the LIF
[fr, i_inj] = lif_fr(1,1,20,0);
line('Parent',handles.axes1,'XData',i_inj,'YData',fr);

%perfect integrator
rin = 20; % in MOhms
tau = 30; % in msec
tref = 1; % in msec
vth = 16; % in mV

%tref = 0;
fr_int = 1./(tref + vth*tau./(i_inj*rin));%in spk/ms
fr_int = 1000*fr_int; %in spk/s

line('Parent',handles.axes1,'XData',i_inj,'YData',fr_int,'Color','r');

%LIF with reset voltage set at 8 mV
[fr_res, i_inj] = lif_fr(1,1,20,8);
line('Parent',handles.axes1,'XData',i_inj,'YData',fr_res,'LineStyle','--');

set(gca,'YLim',[0 600]);
xlabel('current (nA)');
ylabel('firing frequency (spk/s)');


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fi_curves wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fi_curves_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc','fi_lif.eps');

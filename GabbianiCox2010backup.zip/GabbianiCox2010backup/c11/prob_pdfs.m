%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = prob_pdfs(varargin)
% PROB_PDFS M-file for prob_pdfs.fig
%      PROB_PDFS, by itself, creates a new PROB_PDFS or raises the existing
%      singleton*.
%
%      H = PROB_PDFS returns the handle to a new PROB_PDFS or the handle to
%      the existing singleton*.
%
%      PROB_PDFS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROB_PDFS.M with the given input arguments.
%
%      PROB_PDFS('Property','Value',...) creates a new PROB_PDFS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before prob_pdfs_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to prob_pdfs_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help prob_pdfs

% Last Modified by GUIDE v2.5 12-May-2010 21:57:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @prob_pdfs_OpeningFcn, ...
                   'gui_OutputFcn',  @prob_pdfs_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before prob_pdfs is made visible.
function prob_pdfs_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to prob_pdfs (see VARARGIN)

% Choose default command line output for prob_pdfs
handles.output = hObject;

%normal distribution
x = -3.5:0.05:3.5;
y = normpdf(x,0,1);
line('Parent',handles.axes5,'XData',x,'YData',y);
title(handles.axes5,'normal');

%exponential distribution
x = 0:0.05:3;
y = exppdf(x,1);
line('Parent',handles.axes3,'XData',x,'YData',y);
title(handles.axes3,'exponential');

%binomial 1 distribution
n = 100;
p = 0.1;

x = 0:1:20;
y = binopdf(x,n,p);
line('Parent',handles.axes1,'XData',x,'YData',y,'LineStyle','-','Marker','x');
title(handles.axes1,'binomial');

%binomial 2 distribution
n = 12;
p = 0.83;

x = 0:1:20;
y = binopdf(x,n,p);
line('Parent',handles.axes2,'XData',x,'YData',y,'LineStyle','-','Marker','x');
title(handles.axes2,'binomial');

%poisson distribution
lambda = 100*0.1;

x = 0:1:20;
y = poisspdf(x,lambda);
line('Parent',handles.axes4,'XData',x,'YData',y,'LineStyle','-','Marker','x');
title(handles.axes4,'poisson');

%gamma distribution
x = 0:0.05:10;
y = gampdf(x,3,1);
line('Parent',handles.axes6,'XData',x,'YData',y,'LineStyle','-');
title(handles.axes6,'gamma');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes prob_pdfs wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = prob_pdfs_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


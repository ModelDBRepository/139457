%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = poiss1(varargin)
% POISS1 M-file for poiss1.fig
%      POISS1, by itself, creates a new POISS1 or raises the existing
%      singleton*.
%
%      H = POISS1 returns the handle to a new POISS1 or the handle to
%      the existing singleton*.
%
%      POISS1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in POISS1.M with the given input arguments.
%
%      POISS1('Property','Value',...) creates a new POISS1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before poiss1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to poiss1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help poiss1

% Last Modified by GUIDE v2.5 21-Apr-2009 10:08:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @poiss1_OpeningFcn, ...
                   'gui_OutputFcn',  @poiss1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before poiss1 is made visible.
function poiss1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to poiss1 (see VARARGIN)

% Choose default command line output for poiss1
handles.output = hObject;

m0 = 2;
m1 = 4;

x0 = 0:6;
y0 = poisspdf(x0,m0);
line('Parent',handles.axes1,'XData',x0,'YData',y0,'LineStyle','--','Marker','o');

x1 = 0:9;
y1 = poisspdf(x1,m1);
line('Parent',handles.axes1,'XData',x1,'YData',y1,'LineStyle','-','Marker','s');
xlabel(handles.axes3,'number of spikes');
ylabel(handles.axes1,'probability of occurence');

%for thresholds k_0 of zero to six
p_fa = [1 1 - poisscdf(0:5,m0)];
p_d  = [1 1 - poisscdf(0:5,m1)];

line('Parent',handles.axes2,'XData',p_fa,'YData',p_d,'Marker','^');

m0 = 4;
m1 = 10;

%for thresholds k_0 of zero to six
p_fa = [1 1 - poisscdf(0:8,m0)];
p_d  = [1 1 - poisscdf(0:8,m1)];

line('Parent',handles.axes2,'XData',p_fa,'YData',p_d,'Marker','*');

line('Parent',handles.axes2,'XData',[0 1],'Ydata',[0 1],'Linestyle','--');
set(handles.axes2,'XLim',[0 1],'YLim',[0 1]);
xlabel(handles.axes2,'probability of false-alarm');
ylabel(handles.axes2,'probability of detection');

m0 = 30;
m1 = 50;
sigma = 10;

x0 = 0:70;
y0 = normpdf(x0,m0,sigma);

line('Parent',handles.axes3,'XData',x0,'YData',y0);

x1 = 10:90;
y1 = normpdf(x1,m1,sigma);

line('Parent',handles.axes3,'XData',x1,'YData',y1);
ylabel(handles.axes3,'probability of occurence');

%compute the 
d = (m1-m0)/sigma;

xi = -3:0.1:3;
p_fa = 1 - normcdf(xi);
p_d =  1 - normcdf(xi - d);

line('Parent',handles.axes4,'XData',p_fa,'YData',p_d);

%compute the case d = 1
d = 1;
p_d = 1 - normcdf(xi - d);

line('Parent',handles.axes4,'XData',p_fa,'YData',p_d,'Color','r');

line('Parent',handles.axes4,'XData',[0 1],'Ydata',[0 1],'Linestyle','--');
set(handles.axes4,'XLim',[0 1],'YLim',[0 1]);
xlabel(handles.axes4,'probability of false-alarm');
ylabel(handles.axes4,'probability of detection');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes poiss1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = poiss1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','poiss1.eps');

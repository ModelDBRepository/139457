%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = fisher_fig(varargin)
% FISHER_FIG M-file for fisher_fig.fig
%      FISHER_FIG, by itself, creates a new FISHER_FIG or raises the existing
%      singleton*.
%
%      H = FISHER_FIG returns the handle to a new FISHER_FIG or the handle to
%      the existing singleton*.
%
%      FISHER_FIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FISHER_FIG.M with the given input arguments.
%
%      FISHER_FIG('Property','Value',...) creates a new FISHER_FIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gauss_fig_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fisher_fig_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fisher_fig

% Last Modified by GUIDE v2.5 27-Apr-2009 16:53:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fisher_fig_OpeningFcn, ...
                   'gui_OutputFcn',  @fisher_fig_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fisher_fig is made visible.
function fisher_fig_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fisher_fig (see VARARGIN)

% Choose default command line output for fisher_fig
handles.output = hObject;

%rotation angle in radians
alpha = 20* (pi/180);
%rotation matrix
R = [cos(alpha) -sin(alpha);sin(alpha) cos(alpha)];

x = -4:0.2:4;
y = -2:0.2:4;
n_x = length(x);
n_y = length(y);
C0 = R'*[1 -0.3;-0.3 1]*R;
C0i = inv(C0);
dC0 = det(C0);
c_z0 = 1/(2*pi*sqrt(dC0));

n0 = [-1; 1];
z = zeros(n_y,n_x);
for i = 1:n_x
    for j = 1:n_y
        v = [x(i); y(j)];
        vz = v - n0;
        z(j,i) = c_z0*exp(-0.5*vz'*C0i*vz);
    end;
end;


contour(handles.axes1,x,y,z,'EdgeColor','black');
hold on;

%%%%%%%%%%%%

x = -4:0.2:4;
y = -4:0.2:4;
n_x = length(x);
n_y = length(y);
C1 = R'*[1 0.8;0.8 1]*R;
C1i = inv(C1);
dC1 = det(C1);
c_z1 = 1/(2*pi*sqrt(dC1));

n1 = [1; 1];
z = zeros(n_x,n_x);
for i = 1:n_x
    for j = 1:n_y
        v = [x(i); y(j)];
        vz = v - n1;
        z(j,i) = c_z1*exp(-0.5*vz'*C1i*vz);
    end;
end;

%mesh(handles.axes2,x,x,z,'EdgeColor','black');
contour(handles.axes1,x,x,z,'EdgeColor','red');
set(handles.axes1,'XLim',[-4 4],'YLim',[-4 4],'TickDir','out');


%compute the best direction according to the Fisher method
wopt = inv(C1+C0)*(n1-n0);
wopt = wopt/norm(wopt);

line('Parent',handles.axes1,'XData',[0 wopt(1)],'YData',[0 wopt(2)],'Color','b');
line('Parent',handles.axes1,'XData',[0 wopt(1)],'YData',[0 wopt(2)],'Color','b');
xlabel(handles.axes1,'Data dimension 1');
ylabel(handles.axes1,'Data dimension 2');

mu0 = wopt'*n0;
sig0 = wopt'*C0*wopt;

dx0 = 6*sig0/100;
x0 = mu0-3*sig0:dx0:mu0+3*sig0;
y0 = normpdf(x0,mu0,sig0);
line('Parent',handles.axes2,'XData',x0,'YData',y0);

mu1 = wopt'*n1;
sig1 = wopt'*C1*wopt;

dx1 = 6*sig1/100;
x1 = mu1-3*sig1:dx1:mu1+3*sig1;
y1 = normpdf(x1,mu1,sig1);
line('Parent',handles.axes2,'XData',x1,'YData',y1,'Color','r');
set(handles.axes2,'XLim',[-4 4]);
xlabel(handles.axes2,'Projection on optimal discrimination direction');
ylabel(handles.axes2,'Probability density');

wper = [-wopt(2); wopt(1)];

mu0p = wper'*n0;
sig0p = wper'*C0*wper;

dx0p = 6*sig0p/100;
x0p = mu0p-3*sig0p:dx0p:mu0p+3*sig0p;
y0p = normpdf(x0p,mu0p,sig0p);
line('Parent',handles.axes3,'XData',x0p,'YData',y0p);

mu1p = wper'*n1;
sig1p = wper'*C1*wper;

dx1p = 6*sig1p/100;
x1p = mu1p-3*sig1p:dx1p:mu1p+3*sig1p;
y1p = normpdf(x1p,mu1p,sig1p);
line('Parent',handles.axes3,'XData',x1p,'YData',y1p,'Color','r');
set(handles.axes3,'XLim',[-4 4]);
xlabel(handles.axes3,'Orthogonal projection');
ylabel(handles.axes3,'Probability density');


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fisher_fig wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fisher_fig_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','fisher_fig.eps');



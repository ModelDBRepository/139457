%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = wang_ss(varargin)
% WANG_SS M-file for wang_ss.fig
%      WANG_SS, by itself, creates a new WANG_SS or raises the existing
%      singleton*.
%
%      H = WANG_SS returns the handle to a new WANG_SS or the handle to
%      the existing singleton*.
%
%      WANG_SS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WANG_SS.M with the given input arguments.
%
%      WANG_SS('Property','Value',...) creates a new WANG_SS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before wang_ss_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to wang_ss_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help wang_ss

% Last Modified by GUIDE v2.5 06-Jan-2009 14:33:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @wang_ss_OpeningFcn, ...
                   'gui_OutputFcn',  @wang_ss_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before wang_ss is made visible.
function wang_ss_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to wang_ss (see VARARGIN)

% Choose default command line output for wang_ss
handles.output = hObject;


v = -120:1:0;

%steady-state activation curve of low-threshold Ca current
sinf = 1./(1+exp(-(v+65)/7.8));

%steady-state inactivation of low-threshold Ca current
thh = -81;
kh = 6.25;
hinf = 1./(1+exp((v-thh)/kh));

%steady-state activation of H current
Hinf = 1./(1+exp((v+69)/7.1));

%plot results
line('Parent',handles.axes1,'XData',v,'YData',sinf);
line('Parent',handles.axes1,'XData',v,'YData',hinf,'LineStyle',':');
line('Parent',handles.axes1,'XData',v,'YData',Hinf,'Color','r');
set(handles.axes1,'XLim',[-120 -10]);

%time constant of (de-)inactivation of T-type calcium current
tauh = hinf.*exp((v+162.3)/17.8) + 20;
tauh = tauh/2; %temperature scaling factor

%time constant of H current
tauH = 1000./(exp((v+66.4)/9.3)+exp(-(v+81.6)/13));

line('Parent',handles.axes2,'XData',v,'YData',tauh);
line('Parent',handles.axes3,'XData',v,'YData',tauH,'Color','r');
set(handles.axes2,'XLim',[-120 -10]);
set(handles.axes3,'XLim',[-120 -10],'Color','none');

xlabel(handles.axes1,'membrane potential (mV)');
xlabel(handles.axes3,'membrane potential (mV)');
ylabel(handles.axes2,'I_T inactivation time constant (ms)');
ylabel(handles.axes3,'I_H activation time constant (ms)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes wang_ss wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = wang_ss_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','wang_ss.eps');


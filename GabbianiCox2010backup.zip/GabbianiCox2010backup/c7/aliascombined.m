%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = aliascombined(varargin)
% ALIASCOMBINED M-file for aliascombined.fig
%      ALIASCOMBINED, by itself, creates a new ALIASCOMBINED or raises the existing
%      singleton*.
%
%      H = ALIASCOMBINED returns the handle to a new ALIASCOMBINED or the handle to
%      the existing singleton*.
%
%      ALIASCOMBINED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ALIASCOMBINED.M with the given input arguments.
%
%      ALIASCOMBINED('Property','Value',...) creates a new ALIASCOMBINED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before aliascombined_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to aliascombined_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help aliascombined

% Last Modified by GUIDE v2.5 23-Jul-2009 15:48:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @aliascombined_OpeningFcn, ...
                   'gui_OutputFcn',  @aliascombined_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before aliascombined is made visible.
function aliascombined_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to aliascombined (see VARARGIN)

% Choose default command line output for aliascombined
handles.output = hObject;

x = 0:0.01:1;
y = sin(2*pi*x);
z = sin(2*pi*3*x);

%h = figure(1);
%set(h,'Position',[1 1 712 358]);

%h1 = subplot(1,2,1);
%plot(x,y,'b');
line('Parent',handles.axes1,'XData',x,'YData',y,'Color','k');
%hold on;
%plot(x,z,'r');
line('Parent',handles.axes1,'XData',x,'YData',z,'Color','r');
line('Parent',handles.axes1,'XData',[0 0.5 1],'YData',[0 0 0],'Marker','x','MarkerSize',8,'Color','k');

%set(h1,'TickDir','out');
%xlabel('time (s)');
%ylabel('response (arbitrary units)');

%h2 = subplot(1,2,2);
%plot(x,y+z,'m');
line('Parent',handles.axes2,'XData',x,'YData',y+z,'Color','k');
%hold on;
%plot(x,2*y,'b');
line('Parent',handles.axes2,'XData',x,'YData',2*y,'Color','r');
line('Parent',handles.axes2,'XData',[0 0.5 1],'YData',[0 0 0],'Marker','x','MarkerSize',8,'Color','k');

%set(h2,'TickDir','out');
%xlabel('\omega (Hz)');
%ylabel('phase (deg)');

%%%

N = 16;
T = 10;
dt = T/N;
t = 0:dt:T-dt;
u = sin(2*pi*t);
line('Parent',handles.axes3,'XData',t,'YData',u,'Color','k');

f = (0:N/2)/T;
c = fft(u)/N;
line('Parent',handles.axes4,'XData',f,'YData',abs(c(1:1+N/2)),'Color','k');

N =32;

dt = T/N;
t = 0:dt:T-dt;
u = sin(2*pi*t);
line('Parent',handles.axes3,'XData',t,'YData',u,'Color','r');
axis(handles.axes3,'tight'); 
box(handles.axes3,'off');
legend(handles.axes3,'N=16','N=32','location','best','boxoff');
xlabel(handles.axes3,'t  (s)','fontsize',10)
ylabel(handles.axes3,'u','fontsize',10)

f = (0:N/2)/T;
c = fft(u)/N;
line('Parent',handles.axes4,'XData',f,'YData',abs(c(1:1+N/2)),'Color','r');
axis(handles.axes4,'tight');
box(handles.axes4,'off');
legend(handles.axes4,'N=16','N=32','location','best','boxoff');
xlabel(handles.axes4,'\omega (Hz)','fontsize',10)
ylabel(handles.axes4,'|c|','fontsize',10)

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes aliascombined wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = aliascombined_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','aliascombined.eps');

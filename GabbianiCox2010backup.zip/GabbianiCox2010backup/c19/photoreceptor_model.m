%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires fly_phot9.m

function varargout = photoreceptor_model(varargin)
% PHOTORECEPTOR_MODEL M-file for photoreceptor_model.fig
%      PHOTORECEPTOR_MODEL, by itself, creates a new PHOTORECEPTOR_MODEL or raises the existing
%      singleton*.
%
%      H = PHOTORECEPTOR_MODEL returns the handle to a new PHOTORECEPTOR_MODEL or the handle to
%      the existing singleton*.
%
%      PHOTORECEPTOR_MODEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PHOTORECEPTOR_MODEL.M with the given input arguments.
%
%      PHOTORECEPTOR_MODEL('Property','Value',...) creates a new PHOTORECEPTOR_MODEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before photoreceptor_model_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to photoreceptor_model_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help photoreceptor_model

% Last Modified by GUIDE v2.5 21-Feb-2009 15:36:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @photoreceptor_model_OpeningFcn, ...
                   'gui_OutputFcn',  @photoreceptor_model_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before photoreceptor_model is made visible.
function photoreceptor_model_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to photoreceptor_model (see VARARGIN)

% Choose default command line output for photoreceptor_model
handles.output = hObject;

t_v = [1:1500];
rint_ts = zeros(1,1500);
rint_ts(1:500) = 500;
rint_ts(1001:1500) = 500;

c = [-0.8 -0.4 -0.2 -0.1 0.1 0.2 0.4 0.8 1.6 3.2 6.4];

for i = 1:length(c)
    rint_ts(501:1000) = 500 + c(i)*500;
    [x_a x_b x_c x_d x_e x_f x_g x_h] = fly_phot9(rint_ts);

    %plot each of the raw variables
    line('Parent',handles.axes1,'XData',t_v,'YData',x_h,'Color','k');
end;

xlabel(handles.axes1,'time (ms)');
ylabel(handles.axes1,'response (mV)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes photoreceptor_model wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = photoreceptor_model_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


print(handles.figure1,'-depsc2','photoreceptor_model.eps');


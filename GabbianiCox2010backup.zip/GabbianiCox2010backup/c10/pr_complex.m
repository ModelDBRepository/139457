%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires prsolve.m 
%

function varargout = pr_complex(varargin)
% PR_COMPLEX M-file for pr_complex.fig
%      PR_COMPLEX, by itself, creates a new PR_COMPLEX or raises the existing
%      singleton*.
%
%      H = PR_COMPLEX returns the handle to a new PR_COMPLEX or the handle to
%      the existing singleton*.
%
%      PR_COMPLEX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PR_COMPLEX.M with the given input arguments.
%
%      PR_COMPLEX('Property','Value',...) creates a new PR_COMPLEX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pr_complex_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pr_complex_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pr_complex

% Last Modified by GUIDE v2.5 11-May-2010 22:05:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pr_complex_OpeningFcn, ...
                   'gui_OutputFcn',  @pr_complex_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pr_complex is made visible.
function pr_complex_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pr_complex (see VARARGIN)

% Choose default command line output for pr_complex
handles.output = hObject;

[t,y] = prsolve(1500,[0.75 0.0 2.1]);

line('Parent',handles.axes1,'XData',t,'YData',y(:,1));
line('Parent',handles.axes1,'XData',t,'YData',y(:,2),'Color','r');
set(handles.axes1,'XLim',[970 1000],'YLim',[-10 90]);
ylabel(handles.axes1,'membrane potential (mV)');

%compute the corresponding currents
z = currents_from(y,2.1);

line('Parent',handles.axes2,'XData',t,'YData',z(:,1));
line('Parent',handles.axes2,'XData',t,'YData',z(:,2));
line('Parent',handles.axes2,'XData',t,'YData',z(:,3));
set(handles.axes2,'XLim',[970 1000],'YLim',[-1800 500]);
xlabel(handles.axes2,'time (ms)');
ylabel(handles.axes2,'current (mA/cm2)');

line('Parent',handles.axes3,'XData',t,'YData',z(:,4));
line('Parent',handles.axes3,'XData',t,'YData',z(:,5));
line('Parent',handles.axes3,'XData',t,'YData',z(:,6));
line('Parent',handles.axes3,'XData',t,'YData',50*z(:,7),'Color','r');
set(handles.axes3,'XLim',[970 1000],'YLim',[-800 800]);


line('Parent',handles.axes4,'XData',t,'YData',z(:,8));
set(handles.axes4,'XLim',[970 1000]); %,'YLim',[-20 120]);
xlabel(handles.axes4,'time (ms)');
ylabel(handles.axes4,'current (mA/cm2)');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pr_complex wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pr_complex_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','pr_complex.eps');

function z = currents_from(y,gc)

%maximal conductances in mS/cm^2
gL = 0.1; %leak
gNa = 30; %fast sodium
gKDR = 15; %delayed rectifier
gCa = 10; %fast calcium current
gKAHP = 0.8; %calcium dependent potassium current (slow)
gKC = 15; %voltage and calcium dependent potassium current (fast)

%reversal potentials (in mV)
VNa = 120; VCa = 140; VK = -15; VL = 0;

%fraction of cable length assigned to soma (1-p for dendrite)
p = 0.5;

%somatic leak current
Ils = gL*(y(:,1)-VL);

%steady-state sodium activation (instantaneous)
minf = am(y(:,1))./(am(y(:,1))+bm(y(:,1)));

%sodium current (y(3) is h, inactivation of sodium current)
INa = gNa*minf.^2.*y(:,3).*(y(:,1)-VNa);

%delayed rectifier current (y(4) is n, activation of DR)
IKDR = gKDR*y(:,4).*(y(:,1)-VK);

%dendritic leak current
Ild = gL*(y(:,2)-VL);

%dendritic calcium current (y(5) is s activation variable)
ICa = gCa*y(:,5).^2.*(y(:,2)-VCa);

%voltage and calcium dependent K current (y(6) is c activation variable,
%y(8) is Ca)
IKC = gKC*y(:,6).*min(y(:,8)/250,1).*(y(:,2)-VK);

%calcium dependent K current (y(7) is q activation variable)
IKAHP = gKAHP*y(:,7).*(y(:,2)-VK);

Idtos = (gc/p)*(y(:,2)-y(:,1));

z = [Ils INa IKDR Ild ICa IKC IKAHP Idtos];

return;

%
%For following rate constants, see eq. 6 of [PR94] and erratum
%

%forward rate constant for fast sodium
function val = am(v)
val = 0.32*(13.1-v)./(exp((13.1-v)/4)-1);

%backward rate constant for fast sodium
function val = bm(v)
val = 0.28*(v-40.1)./(exp((v-40.1)/5)-1);

%
% Gabbiani & Cox, Mathematics for Neuroscientists
%
% stmolierr.m
%
% evaluate the accuracy of staggered Euler on the Molineaux system
%

close all

Tfin = 15;
I0 = 300;

[t6,v6] = stmoli(1e-6,Tfin,I0);
[t5,v5] = stmoli(1e-5,Tfin,I0);
[t4,v4] = stmoli(1e-4,Tfin,I0);
[t3,v3] = stmoli(1e-3,Tfin,I0);
[t2,v2] = stmoli(1e-2,Tfin,I0);
[t1,v1] = stmoli(1e-1,Tfin,I0);

er(1) = norm(v1-v6(1:1e5:end),inf);
er(2) = norm(v2-v6(1:1e4:end),inf); 
er(3) = norm(v3-v6(1:1e3:end),inf); 
er(4) = norm(v4-v6(1:1e2:end),inf);
er(5) = norm(v5-v6(1:1e1:end),inf);

loglog([1e-1 1e-2 1e-3 1e-4 1e-5],er,'kx-')
xlabel('dt (ms)','fontsize',14)
ylabel('E (mV)','fontsize',14)

%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = fftexcoarse2(varargin)
% FFTEXCOARSE2 M-file for fftexcoarse2.fig
%      FFTEXCOARSE2, by itself, creates a new FFTEXCOARSE2 or raises the existing
%      singleton*.
%
%      H = FFTEXCOARSE2 returns the handle to a new FFTEXCOARSE2 or the handle to
%      the existing singleton*.
%
%      FFTEXCOARSE2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FFTEXCOARSE2.M with the given input arguments.
%
%      FFTEXCOARSE2('Property','Value',...) creates a new FFTEXCOARSE2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fftexcoarse2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fftexcoarse2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fftexcoarse2

% Last Modified by GUIDE v2.5 23-Jul-2009 13:10:54

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fftexcoarse2_OpeningFcn, ...
                   'gui_OutputFcn',  @fftexcoarse2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fftexcoarse2 is made visible.
function fftexcoarse2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fftexcoarse2 (see VARARGIN)

% Choose default command line output for fftexcoarse2
handles.output = hObject;

%
% fftexcoarse
%

N = 10;
T = 10;
dt = T/N;
t = 0:dt:T-dt;
u = t.*(4-t).*(10-t);

line('Parent',handles.axes1,'XData',t,'YData',u,...
    'Color','k','Marker','x','LineStyle','-');
axis(handles.axes1,'tight'); 
box(handles.axes1,'off');
xlabel(handles.axes1,'t  (s)','fontsize',10)
ylabel('u','fontsize',10)

uhat = fft(u);
line('Parent',handles.axes2,'XData',[0:N-1],'YData',real(uhat),...
    'Color','k','Marker','x','LineStyle','-');
line('Parent',handles.axes2,'XData',[0:N-1],'YData',imag(uhat),...
    'Color','r','Marker','o','LineStyle','-');
legend(handles.axes2,'real part','imaginary part','location','best')
xlabel(handles.axes2,'index','fontsize',10)
ylabel(handles.axes2,'uhat','fontsize',10)
axis(handles.axes2,'tight');
box(handles.axes2,'off');

f = [0:floor(N/2) -(ceil(N/2)-1:-1:1)]/T;
f_shift = circshift(f,[0 (N-2)/2]);
ruhat_shift = circshift(real(uhat),[0 (N-2)/2]);
iuhat_shift = circshift(imag(uhat),[0 (N-2)/2]);
line('Parent',handles.axes3,'XData',f_shift,'YData',ruhat_shift,...
    'Color','k','Marker','x','LineStyle','-');
line('Parent',handles.axes3,'XData',f_shift,'YData',iuhat_shift,...
    'Color','r','Marker','o','LineStyle','-');

%legend(handles.axes3,'real part','imaginary part','location','best')
xlabel(handles.axes3,'\omega  (Hz)','fontsize',10)
%ylabel('uhat','fontsize',10)
axis(handles.axes3,'tight');
box(handles.axes3,'off');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fftexcoarse2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fftexcoarse2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','fftexcoarse2.eps');

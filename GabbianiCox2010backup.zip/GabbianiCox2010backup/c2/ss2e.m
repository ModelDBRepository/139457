%
% Gabbiani & Cox,  Mathematics for Neuroscientists
% 
% ss2e.m
%

VCl = -68;
ce = 0:.1:15;

Vsse = VCl - (ce./(1+ce))*VCl;

Vss2e = VCl - (2*ce./(1+2*ce))*VCl;

Vsse2 = VCl - (2*ce./(1+ce))*VCl;


plot(ce,Vsse,'k')
hold on
plot(ce,Vss2e,'r')
plot(ce,Vsse2,'k--')
hold off
box off
legend('V_{ss,e}','V_{ss,2e}','V_{ss,e2}','location','best')
xlabel('c_e','fontsize',14)
ylabel('mV','fontsize',14)

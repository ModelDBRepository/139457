%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = fourierex2(varargin)
% FOURIEREX2 M-file for fourierex2.fig
%      FOURIEREX2, by itself, creates a new FOURIEREX2 or raises the existing
%      singleton*.
%
%      H = FOURIEREX2 returns the handle to a new FOURIEREX2 or the handle to
%      the existing singleton*.
%
%      FOURIEREX2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FOURIEREX2.M with the given input arguments.
%
%      FOURIEREX2('Property','Value',...) creates a new FOURIEREX2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fourierex2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fourierex2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fourierex2

% Last Modified by GUIDE v2.5 23-Jul-2009 12:32:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fourierex2_OpeningFcn, ...
                   'gui_OutputFcn',  @fourierex2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fourierex2 is made visible.
function fourierex2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fourierex2 (see VARARGIN)

% Choose default command line output for fourierex2
handles.output = hObject;

% fourierex

x = -0.5:.005:0.5;

f = ones(size(x))/pi;
for n=1:10,
    f = f + 2*sin(n)*cos(n*2*pi*x)/pi/n;
end
line('Parent',handles.axes1,'XData',x,'YData',f,'Color','r');
f = ones(size(x))/pi;
for n=1:100,
    f = f + 2*sin(n)*cos(n*2*pi*x)/pi/n;
end
line('Parent',handles.axes1,'XData',x,'YData',f,'Color','k');
axis(handles.axes1,'tight');
box(handles.axes1,'off');
legend(handles.axes1,'N=10','N=100')
xlabel(handles.axes1,'x','fontsize',14)

f = ones(size(x));
for n=1:10,
    f = f + 2*cos(n*2*pi*x);
end
line('Parent',handles.axes2,'XData',x,'YData',f,'Color','r');
f = ones(size(x));
for n=1:100,
    f = f + 2*cos(n*2*pi*x);
end
line('Parent',handles.axes2,'XData',x,'YData',f,'Color','k');
axis(handles.axes2,'tight');
box(handles.axes2,'off');
legend(handles.axes2,'N=10','N=100');
xlabel(handles.axes2,'x','fontsize',14)

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fourierex2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fourierex2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','fourierex2.eps');

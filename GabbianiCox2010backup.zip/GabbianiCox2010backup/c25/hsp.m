%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = hsp(varargin)
% HSP M-file for hsp.fig
%      HSP, by itself, creates a new HSP or raises the existing
%      singleton*.
%
%      H = HSP returns the handle to a new HSP or the handle to
%      the existing singleton*.
%
%      HSP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HSP.M with the given input arguments.
%
%      HSP('Property','Value',...) creates a new HSP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hsp_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hsp_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hsp

% Last Modified by GUIDE v2.5 28-Apr-2009 15:18:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hsp_OpeningFcn, ...
                   'gui_OutputFcn',  @hsp_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hsp is made visible.
function hsp_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hsp (see VARARGIN)

% Choose default command line output for hsp
handles.output = hObject;


%this m-file reproduces the HSP figure 7

%load the first data set subject sh
load sh_dat1.txt

%log base 10 of the mean number of photons
x_sh1 = log10(sh_dat1(:,1));

%convert to percents
y_sh1 = sh_dat1(:,2)/100;

%plot the data
line('Parent',handles.axes1,'XData',x_sh1,'YData',y_sh1,'Marker','x','LineStyle','none');

%typical log10 range for the poisson cpf
x_cp1 = -0.25:0.01:1.25;

%compute cpf at 6 and no absorption factor, no dark photons
y_cp1 = p_c(x_cp1,6,1,0);

%index for the approximate mid-value of the cumulative function
[v_m1, ind_m1] = min(abs(y_cp1 - 0.5));
x_m1 = x_cp1(ind_m1);

%find the mid value of the data by linear interpolation. Since the last two
%values of y_hsp1 are 1.0, use only the first one for a vector of length 5.
x_mid1 = interp1(y_sh1(1:5),x_sh1(1:5),0.5);

%Use this value to translate the poisson cpf to get a good match
x_d1 = x_mid1 - x_m1;

line('Parent',handles.axes1,'XData',x_cp1+x_d1,'YData',y_cp1,'Color','r');
set(handles.axes1,'XLim',[1 3]);

%load the first data set subject sh
load ss_dat1.txt

%log base 10 of the mean number of photons
x_ss1 = log10(ss_dat1(:,1));

%convert to percents
y_ss1 = ss_dat1(:,2)/100;

%plot the data
line('Parent',handles.axes2,'XData',x_ss1,'YData',y_ss1,'Marker','x','LineStyle','none');

%compute cpf at 6 and no absorption factor, no dark photons
y_cp2 = p_c(x_cp1,7,1,0);

%index for the approximate mid-value of the cumulative function
[v_m2,ind_m2] = min(abs(y_cp2 -0.5));
x_m2 = x_cp1(ind_m2);

%find the mid value of the data by linear interpolation. Since the last two
%values of y_hsp1 are 1.0, use only the first one for a vector of length 5.
x_mid2 = interp1(y_ss1,x_ss1,0.5);

%Use this value to translate the poisson cpf to get a good match
x_d2 = x_mid2 - x_m2;

line('Parent',handles.axes2,'XData',x_cp1+x_d2,'YData',y_cp2,'Color','r');
set(handles.axes2,'XLim',[1 3]);

%load the first data set subject sh
load mhp_dat1.txt

%log base 10 of the mean number of photons
x_mhp1 = log10(mhp_dat1(:,1));

%convert to percents
y_mhp1 = mhp_dat1(:,2)/100;

%plot the data
line('Parent',handles.axes3,'XData',x_mhp1,'YData',y_mhp1,'Marker','x','LineStyle','none');

%compute cpf at 5 and no absorption factor, no dark photons
y_cp3 = p_c(x_cp1,5,1,0);

%index for the approximate mid-value of the cumulative function
[v_m3, ind_m3] = min(abs(y_cp3-0.5));
x_m3 = x_cp1(ind_m3);

%find the mid value of the data by linear interpolation. Since the first two
%values of y_mhp1 are 0.6, use only the second one for a vector of length 5.
x_mid3 = interp1(y_mhp1(2:6),x_mhp1(2:6),0.5);
%x_mid3 = x_mhp1(3);

%Use this value to translate the poisson cpf to get a good match
x_d3 = x_mid3 - x_m3;

line('Parent',handles.axes3,'XData',x_cp1+x_d3,'YData',y_cp3,'Color','r');
set(handles.axes3,'XLim',[1 3]);

x_cp = -1:0.01:2;
for i = 1:8
    y = p_c(x_cp,i,1,0);
    line('Parent',handles.axes4,'XData',x_cp,'YData',y);
end;

set(handles.axes4,'XLim',[-1 2]);
xlabel(handles.axes4,'log10 (mean nphotons/flash)')
ylabel(handles.axes3,'detection probability');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hsp wait for user response (see UIRESUME)
% uiwait(handles.figure1);

function y = p_c(x,c,alpha,d_p)
%
% function y = p_c(x, c, alpha, d_p)
%  
% cumulative poisson function
% for photon counts
%  
% x is the log10 photon count at the retina
% alpha is the absorption yield factor
% c is the threshold for seeing 
% d_p is the dark photon number
  
%covert back x to linear space
xl = 10.^x;

%corresponding poisson parameter

p_p = alpha*xl + d_p;

y = 1 - poisscdf(c,p_p);

% --- Outputs from this function are returned to the command line.
function varargout = hsp_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','hsp.eps');

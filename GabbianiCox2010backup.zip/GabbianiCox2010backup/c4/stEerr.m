%
% Gabbiani & Cox, Mathematics for Neuroscientists
%
% assess the error in staggered Euler as function of dt
% stEerr.m
%

close all

Tfin = 20;
I0 = 40;
stim = struct('amp',40e-6,'t1',1,'t2',3,'Tfin',20);

[t5,v5] = stE(1e-5,stim);
[t4,v4] = stE(1e-4,stim);
[t3,v3] = stE(1e-3,stim);
[t2,v2] = stE(1e-2,stim);
[t1,v1] = stE(1e-1,stim);

er(1) = norm(v1-v5(1:1e4:end),inf);
er(2) = norm(v2-v5(1:1e3:end),inf); 
er(3) = norm(v3-v5(1:1e2:end),inf); 
er(4) = norm(v4-v5(1:1e1:end),inf);

loglog([1e-1 1e-2 1e-3 1e-4],er,'-kx')
xlabel('dt (ms)','fontsize',14)
ylabel('E (mV)','fontsize',14)

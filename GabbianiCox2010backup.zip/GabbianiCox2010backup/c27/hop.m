%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  hop.m
%
%  Actively choose N black-and-white block letters from the alphabet,
%  store these letters in a Hopfield Weight Matrix, present noisy
%  copies of these letters and graph the response of the Hopfield net
%

function W = hop(N)

close all

A = imread('alpha.png','png');
image(A)
colormap(gray)

disp(['Click at the center of ' num2str(N) ' letters'])

[x,y] = ginput(N);

x = round(x);
y = round(y);

bAjvec = zeros(67*71,N);

for j=1:N
  
    Aj = A(y(j)-100:3:y(j)+100,x(j)-105:3:x(j)+105);
    bAj = (Aj>=100) - (Aj<100);
    bAjvec(:,j) = -reshape(bAj,67*71,1);
    figure(j+1)
    imagesc(bAj)
    colormap(gray)       % display the True Letters
    axis off
    
end

W = bAjvec*bAjvec';   % imprint the letters into the weight matrix

for let = 1:N,

    figure

    for stim=1:9

        s = bAjvec(:,let);
        s = s + randn(size(s))*4;
        s = sign2(s);
        subplot(3,3,stim)
        imagesc(-reshape(s,67,71))
        colormap(gray)              % display a noisy letter

        axis off
        pause
        err = 1;

        while err>0

            ns = sign2(W*s);

            err = max(abs(s-ns));

            s = ns;
            
        end

         imagesc(-reshape(s,67,71)) % reveal the recovered letter
        
    end % stim

end % let

function val = sign2(x)
tmp = sign(x);
val = tmp + abs(tmp) - 1;

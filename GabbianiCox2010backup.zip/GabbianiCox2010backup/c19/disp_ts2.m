%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = disp_ts2(varargin)
% DISP_TS2 M-file for disp_ts2.fig
%      DISP_TS2, by itself, creates a new DISP_TS2 or raises the existing
%      singleton*.
%
%      H = DISP_TS2 returns the handle to a new DISP_TS2 or the handle to
%      the existing singleton*.
%
%      DISP_TS2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DISP_TS2.M with the given input arguments.
%
%      DISP_TS2('Property','Value',...) creates a new DISP_TS2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before disp_ts2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to disp_ts2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help disp_ts2

% Last Modified by GUIDE v2.5 12-Feb-2009 17:50:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @disp_ts2_OpeningFcn, ...
                   'gui_OutputFcn',  @disp_ts2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before disp_ts2 is made visible.
function disp_ts2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to disp_ts2 (see VARARGIN)

% Choose default command line output for disp_ts2
handles.output = hObject;

fid = fopen('timeseries/ts001.bin','r');

%big endian format, ieee-be, 16 bits integer, unsigned, uint16
ts = fread(fid,inf,'uint16','ieee-be');

fclose(fid);

%in samples per sec
f_samp = 1200;

%in sec
dt = 1/f_samp;

%45 mins
n_ts = length(ts);

s_v = (1:n_ts);
tv = s_v*dt;

line('Parent',handles.axes1,'XData',tv,'YData',ts(s_v));
set(handles.axes1,'XLim',[0 2700]);

%45 sec
inds = find ( (tv > 960) & (tv <=1005) );
line('Parent',handles.axes2,'XData',tv(inds),'YData',ts(inds));
ylabel(handles.axes2,'Luminance (arbitrary units)');

%4.5 sec
inds = find ( (tv > 960) & (tv <=964.5) );
line('Parent',handles.axes3,'XData',tv(inds),'YData',ts(inds));
xlabel(handles.axes3,'time (s)');

[n xout] = hist(ts,100);
bar(handles.axes4,xout,n);
set(handles.axes4,'XLim',[-0.1e4 4e4],'TickDir','out');
xlabel(handles.axes4,'Luminance');
ylabel(handles.axes4,'Observations');

[nl xoutl] = hist(log10(ts),100);
bar(handles.axes5,xoutl,nl);
set(handles.axes5,'TickDir','out','XLim',[1 5]);
xlabel(handles.axes5,'log_1_0 (Luminance)');

%the sampling rate is 1200 samples/s = 2*fNyquist
%we have 45 mins of data or 3,240,000 samples
%split in 4.5min data sets or 324,000 samples
%carry out fft on 4096 samples yielding a frequency resolution
%of 1200/4096 = 0.29 Hz. Since 324,000/4096 = 79.1, we use
%79*4096 = 323,584 samples with 416 (=324,000 - 323,584) unused
%or approx. a fraction of 416/324,000 = 0.0013 unused.

%centered at zero 
ts = ts - mean(ts);

l_ts = length(ts);
l_set = l_ts/10;

n_fft = 4096;
n_samp = floor(l_set/4096)*4096;

%positive part of the power spectrum
p_m = zeros(10,2049);

for i = 1:10
    
    %the parameters are:
    %1) the length of the window n_fft = 4096
    %overlap: n_fft/2 = 2048
    %fft size: n_ftt = 4096
    %maximal two-sided frequency 1200 samples/s
    samples = (i-1)*l_set + (1:n_samp);
    [p_v,w_v] = pwelch(ts(samples),n_fft,n_fft/2,n_fft,1200,'twosided');

    p_m(i,:) = p_v(1:2049);
    
    %take only positive frequencies
    flog_v = log10(w_v(2:2049));
    plog_v = log10(p_v(2:2049));

    %use the same df and xx vector for all the data
    %so compute the following only in the first pass
    if ( i == 1 )
        %linear fit to the data to avoid bias to high 
        %frequencies, we need to resample
        df = (flog_v(end) - flog_v(1))/100;
        xx = flog_v(1):df:flog_v(end);
    end;
    
    %resample log10 power spectrum at xx values
    yy = spline(flog_v,plog_v,xx);
    
    %linear fit
    %i_xx = [xx; ones(1,length(xx))]';
    %l_y = i_xx\yy';
    
    %uncomment to plot individual power spectra and fits
    %figure;
    %plot(flog_v,plog_v);
    %hold on;
    %plot(xx,i_xx*l_y,'g');
    
    if (i == 1)
        yy_m = zeros(10,length(yy));
    end;
    
    yy_m(i,:) = yy;
    
end;

p_mean = mean(p_m,1);
line('Parent',handles.axes6,'XData',w_v(1:2049),'YData',p_mean,'Color','k');
set(handles.axes6,'XLim',[0 5],'YLim',[0 8e6]);
xlabel(handles.axes6,'Frequency (Hz)');
ylabel(handles.axes6,'Luminance^2/Hz');

yy_mean = mean(yy_m,1);
yy_std = std(yy_m,0,1);


%linear fit
i_xx = [xx; ones(1,length(xx))]';
l_y = i_xx\yy_mean';

%plot data
line('Parent',handles.axes7,'XData',xx,'YData',yy_mean,'Color','k');
line('Parent',handles.axes7,'XData',xx,'YData',yy_mean+yy_std,'Color','k','LineStyle',':');
line('Parent',handles.axes7,'XData',xx,'YData',yy_mean-yy_std,'Color','k','LineStyle',':');

%plot fit
line('Parent',handles.axes7,'XData',xx,'YData',i_xx*l_y,'Color','r');
set(handles.axes7,'XLim',[-1 3],'YLim',[0 7]);
xlabel(handles.axes7,'log_1_0(Frequency)');
ylabel(handles.axes7,'log_1_0(Luminance^2/Hz)');


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes disp_ts2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = disp_ts2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','disp_ts2.eps');

%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = rand_fig3(varargin)
% RAND_FIG3 M-file for rand_fig3.fig
%      RAND_FIG3, by itself, creates a new RAND_FIG3 or raises the existing
%      singleton*.
%
%      H = RAND_FIG3 returns the handle to a new RAND_FIG3 or the handle to
%      the existing singleton*.
%
%      RAND_FIG3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RAND_FIG3.M with the given input arguments.
%
%      RAND_FIG3('Property','Value',...) creates a new RAND_FIG3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before rand_fig3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to rand_fig3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help rand_fig3

% Last Modified by GUIDE v2.5 13-May-2010 22:01:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @rand_fig3_OpeningFcn, ...
                   'gui_OutputFcn',  @rand_fig3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before rand_fig3 is made visible.
function rand_fig3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to rand_fig3 (see VARARGIN)

% Choose default command line output for rand_fig3
handles.output = hObject;

m_t = 175e-3; %20 ms
t_max = 1; %time we sample process
n_rnd = 3*round(t_max/m_t); %3 times as many samples as needed to be on the safe side
v = exprnd(m_t,1,n_rnd);
v1 = cumsum(v);
v2 = v1(find(v1<t_max));
v3 = [0 v2];
n_v3 = length(v3);
y3 = [0:1:n_v3];

for i = 1:n_v3-1
    line('Parent',handles.axes1,'XData',[v3(i) v3(i+1)],'YData',[y3(i) y3(i)]);
end;
line('Parent',handles.axes1,'XData',[v3(n_v3) 1],'YData',[y3(n_v3) y3(n_v3)]);

for i = 2:n_v3
    line('Parent',handles.axes7,'XData',[v3(i) v3(i)],'YData',[0 0.5]);
end;

set(handles.axes1,'XLim',[0 1]);
set(handles.axes7,'XLim',[0 1]);
set(handles.axes7,'YLim',[0 1]);

v = exprnd(m_t,1,n_rnd);
v1 = cumsum(v);
v2 = v1(find(v1<t_max));
v3 = [0 v2];
n_v3 = length(v3);
y3 = [0:1:n_v3];

for i = 1:n_v3-1
    line('Parent',handles.axes2,'XData',[v3(i) v3(i+1)],'YData',[y3(i) y3(i)]);
end;
line('Parent',handles.axes2,'XData',[v3(n_v3) 1],'YData',[y3(n_v3) y3(n_v3)]);

for i = 2:n_v3
    line('Parent',handles.axes8,'XData',[v3(i) v3(i)],'YData',[0 0.5]);
end;

set(handles.axes2,'XLim',[0 1]);
set(handles.axes8,'XLim',[0 1]);
set(handles.axes8,'YLim',[0 1]);

v = exprnd(m_t,1,n_rnd);
v1 = cumsum(v);
v2 = v1(find(v1<t_max));
v3 = [0 v2];
n_v3 = length(v3);
y3 = [0:1:n_v3];

for i = 1:n_v3-1
    line('Parent',handles.axes3,'XData',[v3(i) v3(i+1)],'YData',[y3(i) y3(i)]);
end;
line('Parent',handles.axes3,'XData',[v3(n_v3) 1],'YData',[y3(n_v3) y3(n_v3)]);

for i = 2:n_v3
    line('Parent',handles.axes9,'XData',[v3(i) v3(i)],'YData',[0 0.5]);
end;

set(handles.axes3,'XLim',[0 1]);
set(handles.axes9,'XLim',[0 1]);
set(handles.axes9,'YLim',[0 1]);
axes(handles.axes9);
xlabel('time (s)');

 
%generate sample paths of inhomogeneous Poisson process with oscillating
% rate
dt = 0.1e-3; %time step in s

%one second
t_v = 0:dt:1-dt;
f_s = 4; %four cycles per s
y_v = 10*(sin(2*pi*f_s*t_v-pi/2) + 1);
line('Parent',handles.axes5,'XData',t_v,'YData',y_v);

n_ind = length(y_v);
y_vdt = y_v*dt; %speed up integration step below

%generate 10 ms bins (100*dt bins times 100 gives 1s)
m_vect = zeros(1,100);

%number of spike trains simulated
n_sims = 1000;
for sims = 1:n_sims
    %simulate an inhomogeneous Poisson spike train
    spk_ind = [];
    ind = 1;
    thres = exprnd(1);
    y_int = 0;
    while ( ind < n_ind )
        while ( (y_int < thres) && (ind < n_ind) )
            y_int = y_int + y_vdt(ind);
            ind = ind + 1;
        end;

        if ( y_int >= thres )
            spk_ind(end+1) = ind-1;
            %rounds to the nearest 10 ms bin
            mvind = floor((ind-1)/100)+1;
            m_vect(mvind) = m_vect(mvind)+1;
            thres = exprnd(1);
            y_int = 0;
        end;
    end;

    if (sims <=10)
        for i = 1:length(spk_ind)
            t_spk = t_v(spk_ind(i));
            line('Parent',handles.axes6,'XData',[t_spk t_spk],'YData',[0.1 0.9]+(sims-1));
        end;
    end;
end;

%average spike number in each bin
m_vect = m_vect/n_sims;
%convert to firing rate, 1/10 ms = 100 spk/s
m_vect = m_vect*100;

%generate a time vector centered at the middle of each
%bin, 5, 15, 25, ...
t_m = (1:100)*10e-3;
t_m = t_m - 5e-3;
line('Parent',handles.axes4,'XData',t_m,'YData',m_vect);
axes(handles.axes5);
xlabel('time (s)');
ylabel('instantaneous firing rate (spk/s)');
 
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes rand_fig3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = rand_fig3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc','rand_fig3.eps'); 

%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = lif_rand_inp(varargin)
% LIF_RAND_INP M-file for lif_rand_inp.fig
%      LIF_RAND_INP, by itself, creates a new LIF_RAND_INP or raises the existing
%      singleton*.
%
%      H = LIF_RAND_INP returns the handle to a new LIF_RAND_INP or the handle to
%      the existing singleton*.
%
%      LIF_RAND_INP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LIF_RAND_INP.M with the given input arguments.
%
%      LIF_RAND_INP('Property','Value',...) creates a new LIF_RAND_INP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lif_rand_inp_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lif_rand_inp_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lif_rand_inp

% Last Modified by GUIDE v2.5 18-Dec-2008 16:48:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lif_rand_inp_OpeningFcn, ...
                   'gui_OutputFcn',  @lif_rand_inp_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lif_rand_inp is made visible.
function lif_rand_inp_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lif_rand_inp (see VARARGIN)

% Choose default command line output for lif_rand_inp
handles.output = hObject;

%
%leaky integrate and fire with random inputs 
%modified from lif_syn.m

%test first constant current injection

%time constant
tau = 20; %ms

%input resistance
R = 10; %MOhms

v_thres = 10; %mV

%integration time step
dt = 0.05; %ms

%simulation time
t_max = 1000;
t_v = 0:dt:t_max-dt;
nt_v = length(t_v);

%compute constants to save time
dttau = dt/tau;
one_dttau = 1-dttau; %forward Euler
m1_dttau = 1/(1+dttau); %backward Euler

%number of simulations
%n_sims = 500;
n_sims = 1; %debugging

%input current
%constant current for debugging purposes
%i_v = 2*ones(size(t_v)); %nA


%to test the effect of a single synaptic input
%i_v = (qex/dt)*[zeros(size([0:dt:10-dt])) 1 zeros(size([10+dt:dt:t_max-dt]))];

%
%
% compute response to current-based excitation only.
%
%

%charge and number of excitatory inputs
qex = 2; %pCb
nex = 500;

%save number of spikes per trial and isi distribution
n_spks_e = zeros(1,n_sims);
isis_e = [];

for j = 1:n_sims
    %EPSP input times uniformly distributed between 0 and t_max
    r_v = sort(t_max*rand(1,nex));

    %find corresponding indices in t_v
    ind_v = ceil(r_v/dt);
    ind_v = ind_v ( (ind_v > 0) & (ind_v <= nt_v) );
    
    %generate pulse current vector
    i_v = zeros(size(t_v));
    i_v(ind_v) = 1;
    i_v = (qex/dt)*i_v;
    i_v_n = dttau * R * i_v;

    v_v = zeros(size(t_v));
    s_v = zeros(size(t_v));


    %simulate LIF response to input
    for i = 2:nt_v
        %forward Euler
        %v_v(i) = one_dttau * v_v(i-1) + i_v_n(i-1);
    
        %backward Euler
        v_v(i) = m1_dttau*(v_v(i-1) + i_v_n(i));
    
        if (v_v(i) >= v_thres)
            v_v(i) = 0;
            s_v(i) = 1;
        end;
    end;
    
    %spike indices
    ind_spk = find(s_v > 0.5);
    
    %compute number of spikes
    n_spks_e(j) = length(ind_spk);
    
    isis_e = [isis_e diff(t_v(ind_spk))]; 
end;

line('Parent',handles.axes1,'XData',t_v,'YData',v_v);


for i = 1:length(ind_spk);
    line('Parent',handles.axes1,'XData',[t_v(ind_spk(i)) t_v(ind_spk(i))],'YData',[0 30]);
end;

set(handles.axes1,'YLim',[-5 30]);

%for constant current input, compare simulated firing rate with theoretical f-i curve
%of LIF neuron
%fr_sim = sum(s_v)/t_max; %spk/ms
%fr_th = -1/(tau*log(1-v_thres/(R*i_v(1))));

%
%
% current-based excitation and inhibition
%
%

%number of inhibitory inputs adjusted for similar firing rate as without
%inhibition
qex = 2; %pCb
nex = 660;
qin = 4; %pCb
nin = 100;

%save number of spikes per trial and isi distribution
n_spks_i = zeros(1,n_sims);
isis_i = [];

for j = 1:n_sims
    %EPSP input times uniformly distributed between 0 and t_max
    r_v = sort(t_max*rand(1,nex));

    %find corresponding indices in t_v
    ind_v = ceil(r_v/dt);
    ind_v = ind_v ( (ind_v > 0) & (ind_v <= nt_v) );
    
    %generate pulse current vector
    i_v = zeros(size(t_v));
    i_v(ind_v) = 1;
    i_v = (qex/dt)*i_v;
    i_v_n = dttau * R * i_v;

    %IPSP input times uniformly distributed between 0 and t_max
    r_v = sort(t_max*rand(1,nin));

    %find corresponding indices in t_v
    ind_v = ceil(r_v/dt);
    ind_v = ind_v ( (ind_v > 0) & (ind_v <= nt_v) );
    
    %generate pulse current vector
    i_v = zeros(size(t_v));
    i_v(ind_v) = 1;
    i_v = (qin/dt)*i_v;
    
    %add to current vector
    i_v_n = i_v_n - dttau * R * i_v;
    
    v_v = zeros(size(t_v));
    s_v = zeros(size(t_v));


    %simulate LIF response to input
    for i = 2:nt_v
        %forward Euler
        %v_v(i) = one_dttau * v_v(i-1) + i_v_n(i-1);
    
        %backward Euler
        v_v(i) = m1_dttau*(v_v(i-1) + i_v_n(i));
    
        if (v_v(i) >= v_thres)
            v_v(i) = 0;
            s_v(i) = 1;
        end;
    end;
    
    %spike indices
    ind_spk = find(s_v > 0.5);
    
    %compute number of spikes
    n_spks_i(j) = length(ind_spk);    
    isis_i = [isis_i diff(t_v(ind_spk))]; 
end;
 
line('Parent',handles.axes2,'XData',t_v,'YData',v_v);

for i = 1:length(ind_spk);
    line('Parent',handles.axes2,'XData',[t_v(ind_spk(i)) t_v(ind_spk(i))],'YData',[0 30]);
end;

set(handles.axes2,'YLim',[-5 30]);

%
%
% conductance-based excitation
%
%

%number of inhibitory inputs adjusted for similar firing rate as without
%inhibition
qex = 2; %pCb
nex = 600;

%excitatory synaptic conductance
t_ex = 1; %ms
v_ex = 70; %mV

%the excitatory conductance in normalized to yield the same charge at rest 
%as the excitatory current sysnapse
g_ex = qex/(exp(1)*v_ex); %microS

%alpha function for excitatory input
t_syn = 0:dt:8*t_ex-dt;
g_se = (g_ex/t_ex)*t_syn.*exp(1-t_syn/t_ex);

%save number of spikes per trial and isi distribution
n_spks_eg = zeros(1,n_sims);
isis_eg = [];

for j = 1:n_sims
    %EPSP input times uniformly distributed between 0 and t_max
    r_v = sort(t_max*rand(1,nex));

    %find corresponding indices in t_v
    ind_v = ceil(r_v/dt);
    ind_v = ind_v ( (ind_v > 0) & (ind_v <= nt_v) );
    
    %generate pulse synaptic activation vector
    i_v = zeros(size(t_v));
    i_v(ind_v) = 1;
    %generate conductance vector
    g_v = conv(i_v,g_se);
    g_v = g_v(1:nt_v);
    %execute multiplication in advance to save time
    g_v_n = dttau * R * g_v;
    
    v_v = zeros(size(t_v));
    s_v = zeros(size(t_v));


    %simulate LIF response to input
    for i = 2:nt_v
        %forward Euler
        %v_v(i) = one_dttau * v_v(i-1) + g_v_n(i-1)*(v_ex-v_v(i-1));
    
        %backward Euler
        v_v(i) = (v_v(i-1) + g_v_n(i)*v_ex)/(1 + dttau + g_v_n(i));
    
        if (v_v(i) >= v_thres)
            v_v(i) = 0;
            s_v(i) = 1;
        end;
    end;
    
    %spike indices
    ind_spk = find(s_v > 0.5);
    
    %compute number of spikes
    n_spks_eg(j) = length(ind_spk);    
    isis_eg = [isis_eg diff(t_v(ind_spk))]; 
end;

line('Parent',handles.axes3,'XData',t_v,'YData',v_v);

for i = 1:length(ind_spk);
    line('Parent',handles.axes3,'XData',[t_v(ind_spk(i)) t_v(ind_spk(i))],'YData',[0 30]);
end;

set(handles.axes3,'YLim',[-5 30]);

%
%
% conductance-based excitation and inhibition
%
%

%number of inhibitory inputs adjusted for similar firing rate as without
%inhibition
qex = 2; %pCb
nex = 690;
qin = 4; %pCb
nin = 100;

%excitatory synaptic conductance
t_ex = 1; %ms
v_ex = 70; %mV

%the excitatory conductance in normalized to yield the same charge at rest 
%as the excitatory current sysnapse
g_ex = qex/(exp(1)*v_ex); %microS

%alpha function for excitatory input
t_syn_e = 0:dt:8*t_ex-dt;
g_se = (g_ex/t_ex)*t_syn_e.*exp(1-t_syn_e/t_ex);

%excitatory synaptic conductance
t_in = 4; %ms
v_in = 0; %mV

%the inhibitory conductance in normalized 
%as the excitatory synapse
g_in = qin/(exp(1)*v_ex); %microS

%alpha function for inhibitory input
t_syn_i = 0:dt:8*t_in-dt;
g_si = (g_in/t_in)*t_syn_i.*exp(1-t_syn_i/t_in);

%save number of spikes per trial and isi distribution
n_spks_ig = zeros(1,n_sims);
isis_ig = [];

for j = 1:n_sims
    %EPSP input times uniformly distributed between 0 and t_max
    r_v = sort(t_max*rand(1,nex));

    %find corresponding indices in t_v
    ind_v = ceil(r_v/dt);
    ind_v = ind_v ( (ind_v > 0) & (ind_v <= nt_v) );
    
    %generate pulse synaptic activation vector
    i_v = zeros(size(t_v));
    i_v(ind_v) = 1;
    %generate conductance vector
    g_ve = conv(i_v,g_se);
    g_ve = g_ve(1:nt_v);
    %execute multiplication in advance to save time
    g_ve_n = dttau * R * g_ve;

    %IPSP input times uniformly distributed between 0 and t_max
    r_v = sort(t_max*rand(1,nin));

    %find corresponding indices in t_v
    ind_v = ceil(r_v/dt);
    ind_v = ind_v ( (ind_v > 0) & (ind_v <= nt_v) );
    
    %generate pulse synaptic activation vector
    i_v = zeros(size(t_v));
    i_v(ind_v) = 1;
    %generate conductance vector
    g_vi = conv(i_v,g_si);
    g_vi = g_vi(1:nt_v);
    %execute multiplication in advance to save time
    g_vi_n = dttau * R * g_vi;
        
    v_v = zeros(size(t_v));
    s_v = zeros(size(t_v));


    %simulate LIF response to input
    for i = 2:nt_v
        %forward Euler
        %v_v(i) = one_dttau * v_v(i-1) + g_ve_n(i-1)*(v_ex-v_v(i-1)) + g_vi_n(i-1)*(v_in-v_v(i-1));
    
        %backward Euler
        v_v(i) = (v_v(i-1) + g_ve_n(i)*v_ex + g_vi_n(i)*v_in)/(1 + dttau + g_ve_n(i) + g_vi_n(i));
    
        if (v_v(i) >= v_thres)
            v_v(i) = 0;
            s_v(i) = 1;
        end;
    end;
    
    %spike indices
    ind_spk = find(s_v > 0.5);
    
    %compute number of spikes
    n_spks_ig(j) = length(ind_spk);    
    isis_ig = [isis_ig diff(t_v(ind_spk))]; 
end;

line('Parent',handles.axes4,'XData',t_v,'YData',v_v);

for i = 1:length(ind_spk);
    line('Parent',handles.axes4,'XData',[t_v(ind_spk(i)) t_v(ind_spk(i))],'YData',[0 30]);
end;

xlabel(handles.axes4,'time (ms)');
ylabel(handles.axes4,'membrane potential (mV)');

set(handles.axes4,'YLim',[-5 30]);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes lif_rand_inp wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = lif_rand_inp_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc','lif_rand_inp.eps');


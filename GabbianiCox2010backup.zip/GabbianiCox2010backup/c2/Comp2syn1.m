%
% Gabbiani & Cox,  Mathematics for Neuroscientists
% 
% Comp2syn1.m
%

ce = 0.01:.01:1000;

ci = [0 1 2];
sty = {'k' 'r' 'k--'};

figure(1)

for i=1:3

    vp = (100/9)*ce./((ci(i)+10/9).*(ce+10/9)-1/81);

    semilogx(ce,vp,sty{i})

    hold on

end

hold off
box off
legend(['c_i = ' num2str(ci(1))],['c_i = ' num2str(ci(2))],['c_i = ' num2str(ci(3))],'location','best')
xlabel('c_e','fontsize',14)
ylabel('v_p','fontsize',14)


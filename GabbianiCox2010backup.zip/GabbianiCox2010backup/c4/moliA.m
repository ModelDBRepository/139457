%
% Gabbiani & Cox, Mathematics for Neuroscientists
%
% Activation and inactivation functionals 
% for the A-type potassium channel
% 
% moliA
%

function moliA

V = -100:.2:20;

ainfin = 1./(1 + exp(-(V + 27)/8.8));

binfin = 1./(1 + exp((V + 68)/6.6));

plot(V,ainfin,V,binfin);
xlabel('V  (mV)','fontsize',16)
text(-67,.7,'b_\infty','fontsize',16)
text(-20,.5,'a_\infty','fontsize',16)

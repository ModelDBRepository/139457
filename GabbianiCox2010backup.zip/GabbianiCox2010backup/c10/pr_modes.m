%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires prsolve.m
%

function varargout = pr_modes(varargin)
% PR_MODES M-file for pr_modes.fig
%      PR_MODES, by itself, creates a new PR_MODES or raises the existing
%      singleton*.
%
%      H = PR_MODES returns the handle to a new PR_MODES or the handle to
%      the existing singleton*.
%
%      PR_MODES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PR_MODES.M with the given input arguments.
%
%      PR_MODES('Property','Value',...) creates a new PR_MODES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pr_modes_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pr_modes_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pr_modes

% Last Modified by GUIDE v2.5 07-Jan-2009 13:48:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pr_modes_OpeningFcn, ...
                   'gui_OutputFcn',  @pr_modes_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pr_modes is made visible.
function pr_modes_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pr_modes (see VARARGIN)

% Choose default command line output for pr_modes
handles.output = hObject;

[t,y] = prsolve(1500,[0.75 0.0 2.1]);

line('Parent',handles.axes1,'XData',t,'YData',y(:,1));
set(handles.axes1,'XLim',[0 1200],'YLim',[-20 120]);
%xlabel(handles.axes1,'time (ms)');
%ylabel(handles.axes1,'membrane potential (mV)');

ca_sf = 1e-3;
line('Parent',handles.axes3,'XData',t,'YData',y(:,7));
line('Parent',handles.axes3,'XData',t,'YData',ca_sf*y(:,8),'Color','r');
set(handles.axes3,'XLim',[0 1200],'YLim',[0 0.4]);

[t,y] = prsolve(500,[2.5 0.0 2.1]);

line('Parent',handles.axes2,'XData',t,'YData',y(:,1));
set(handles.axes2,'XLim',[0 500],'YLim',[-20 120]);
xlabel(handles.axes2,'time (ms)');
ylabel(handles.axes2,'membrane potential (mV)');

line('Parent',handles.axes4,'XData',t,'YData',y(:,7));
line('Parent',handles.axes4,'XData',t,'YData',ca_sf*y(:,8),'Color','r');
set(handles.axes4,'XLim',[0 500],'YLim',[0 0.4]);
xlabel(handles.axes4,'time (ms)');
ylabel(handles.axes4,'IK-AHP activation and Ca');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pr_modes wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pr_modes_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','pr_modes.eps');

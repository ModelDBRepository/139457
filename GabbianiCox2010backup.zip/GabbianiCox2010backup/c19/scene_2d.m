%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%
%  requires the mat files scen_hist and scen_stat 
%  created by disp_hist and disp_im, respectively.

function varargout = scene_2d(varargin)
% SCENE_2D M-file for scene_2d.fig
%      SCENE_2D, by itself, creates a new SCENE_2D or raises the existing
%      singleton*.
%
%      H = SCENE_2D returns the handle to a new SCENE_2D or the handle to
%      the existing singleton*.
%
%      SCENE_2D('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SCENE_2D.M with the given input arguments.
%
%      SCENE_2D('Property','Value',...) creates a new SCENE_2D or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before scene_2d_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to scene_2d_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help scene_2d

% Last Modified by GUIDE v2.5 11-Feb-2009 16:32:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @scene_2d_OpeningFcn, ...
                   'gui_OutputFcn',  @scene_2d_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before scene_2d is made visible.
function scene_2d_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to scene_2d (see VARARGIN)

% Choose default command line output for scene_2d
handles.output = hObject;

%obtained from disp_hist.m
load('scen_hist');

bar(handles.axes1,scene_hist.bins_lin,scene_hist.n_lin_mean);
set(handles.axes1,'XLim',[-1400 5000],'TickDir','out');
xlabel(handles.axes1,'luminance (cd/m2)');
ylabel(handles.axes1,'number of observations');

bar(handles.axes2,scene_hist.bins_log,scene_hist.n_log_mean);
set(handles.axes2,'XLim',[0 4],'TickDir','out');
xlabel(handles.axes2,'log10(luminance)');

%obtained from disp_im.m
load('scen_stat');

line('Parent',handles.axes3,'XData',scene_stat.flog_v,'YData',scene_stat.p_mean);
line('Parent',handles.axes3,'XData',scene_stat.flog_v,'YData',scene_stat.p_mean-scene_stat.p_std,...
    'LineStyle',':');
line('Parent',handles.axes3,'XData',scene_stat.flog_v,'YData',scene_stat.p_mean+scene_stat.p_std,...
    'LineStyle',':');
line('Parent',handles.axes3,'XData',scene_stat.flog_v,'YData',scene_stat.flog_ve*scene_stat.x,'Color','r');
set(handles.axes3,'XLim',[-1 1.5],'YLim',[0.5 6.5]);
xlabel(handles.axes3,'log10(frequency)');
ylabel(handles.axes3,'log10(luminance2/Hz)');

line('Parent',handles.axes4,'XData',scene_stat.w_lin,'YData',scene_stat.p_lin_mean);
set(handles.axes4,'XLim',[0 10]);
xlabel(handles.axes4,'frequency (Hz)');
ylabel(handles.axes4,'(cd/m2)2/Hz');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes scene_2d wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = scene_2d_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','scene_2d.eps');

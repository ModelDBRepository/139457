%
%  Gabbiani & Cox, Mathematics for Neuroscientists
%

function varargout = twostatechan(varargin)
% TWOSTATECHAN M-file for twostatechan.fig
%      TWOSTATECHAN, by itself, creates a new TWOSTATECHAN or raises the existing
%      singleton*.
%
%      H = TWOSTATECHAN returns the handle to a new TWOSTATECHAN or the handle to
%      the existing singleton*.
%
%      TWOSTATECHAN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TWOSTATECHAN.M with the given input arguments.
%
%      TWOSTATECHAN('Property','Value',...) creates a new TWOSTATECHAN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before twostatechan_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to twostatechan_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help twostatechan

% Last Modified by GUIDE v2.5 05-Feb-2009 18:11:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @twostatechan_OpeningFcn, ...
                   'gui_OutputFcn',  @twostatechan_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before twostatechan is made visible.
function twostatechan_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to twostatechan (see VARARGIN)

% Choose default command line output for twostatechan
handles.output = hObject;

%these are the mean of the corresponding exponential distributions 
%given by 1/alpha and 1/beta, respectively
alpha = 100; %in 1/s
m_alpha = 1/alpha;

beta = 500; %in 1/s
m_beta = 1/beta;

n_trans = 30;

s_vect = zeros(1,n_trans);
s_vect(1) = rand(1) < 0.5;

t_vect = zeros(1,n_trans);

for i = 2: n_trans
    if ( s_vect(i-1) == 0 )
        %closed, duration determined by alpha
        tnext = exprnd(m_alpha);
        s_vect(i) = 1;
        t_vect(i) = t_vect(i-1) + tnext;
    else
        %open, duration determined by beta
        tnext = exprnd(m_beta);
        s_vect(i) = 0;
        t_vect(i) = t_vect(i-1) + tnext;
    end;
end;

for i = 2:n_trans
    line('Parent',handles.axes1,'XData',[t_vect(i-1) t_vect(i)],'YData',[s_vect(i-1) s_vect(i-1)]);
    line('Parent',handles.axes1,'XData',[t_vect(i) t_vect(i)],'YData',[s_vect(i-1) s_vect(i)]);
end;
set(handles.axes1,'XLim',[0 100e-3]); %100 ms 

%t_vect(n_trans);

n_chan = 200;
%get approx the same time
n_trans1 = n_trans*n_chan;

%number of open channels
s1_vect = zeros(1,n_trans1);
%s1_vect(1) = round(n_chan*rand(1)); %random number of open channels
s1_vect(1) = 100;

t1_vect = zeros(1,n_trans1);

for i = 2: n_trans1
    %total current transition rate: Nclosed*alpha + Nopen*beta
    nclosed = n_chan-s1_vect(i-1);
    lambda = nclosed*alpha + s1_vect(i-1)*beta;
    
    %time of next transition
    tnext = exprnd(1/lambda);
    t1_vect(i) = t1_vect(i-1) + tnext;
    
    %given a transition, probability of C->O
    lambda1 = nclosed*alpha/lambda;
    
    if ( rand(1) <= lambda1 )
        %C->O transition
        s1_vect(i) = s1_vect(i-1) +1;
    else
        %O->C transition
        s1_vect(i) = s1_vect(i-1) - 1;
    end;
end;

n_max = 1 + 2*(n_trans1-1);
x_v = zeros(1,n_max);
y_v = zeros(1,n_max);
x_v(1) = t1_vect(1);
x_v(2:2:n_max-1) = t1_vect(2:n_trans1);
x_v(3:2:n_max) = t1_vect(2:n_trans1);

y_v(1:2:n_max-2) = s1_vect(1:n_trans1-1);
y_v(2:2:n_max-1) = s1_vect(1:n_trans1-1);
y_v(n_max) = s1_vect(n_trans);
line('Parent',handles.axes2,'XData',x_v,'YData',y_v);

set(handles.axes2,'XLim',[0 100e-3]); %100 ms 
xlabel('time (s)');
ylabel('number of open channels');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes twostatechan wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = twostatechan_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function save_fig_Callback(hObject, eventdata, handles)
% hObject    handle to save_fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

print(handles.figure1,'-depsc2','twostatechan.eps');
